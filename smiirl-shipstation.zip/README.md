# Smiirl ShipStation Integration

Automatically updates a JSON file with current ShipStation order count for use with Smiirl custom counters.
